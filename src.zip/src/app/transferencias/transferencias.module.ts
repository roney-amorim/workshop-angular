import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TransferenciasRoutingModule } from './transferencias-routing.module';
import { InteropComponent } from './interop/interop.component';
import { ItiComponent } from './iti/iti.component';


@NgModule({
  declarations: [InteropComponent, ItiComponent],
  imports: [
    CommonModule,
    TransferenciasRoutingModule
  ]
})
export class TransferenciasModule { }
