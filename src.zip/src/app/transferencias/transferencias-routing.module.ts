import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItiComponent } from './iti/iti.component';
import { InteropComponent } from './interop/interop.component';

const routes: Routes = [
  {path:"interop", component: InteropComponent},
  {path:"iti", component: ItiComponent},
  {path:"", component: ItiComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TransferenciasRoutingModule { }
