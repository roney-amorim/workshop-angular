import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItiComponent } from './iti.component';

describe('ItiComponent', () => {
  let component: ItiComponent;
  let fixture: ComponentFixture<ItiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
