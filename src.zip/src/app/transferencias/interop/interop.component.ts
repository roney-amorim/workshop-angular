import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interop',
  templateUrl: './interop.component.html',
  styleUrls: ['./interop.component.css']
})
export class InteropComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
