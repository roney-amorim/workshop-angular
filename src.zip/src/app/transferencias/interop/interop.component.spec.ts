import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InteropComponent } from './interop.component';

describe('InteropComponent', () => {
  let component: InteropComponent;
  let fixture: ComponentFixture<InteropComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InteropComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InteropComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
