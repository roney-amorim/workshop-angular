import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  get isUserLoggedIn(){
    return this.loggedIn.asObservable();

  }
  constructor(private router: Router) { }

  login(usuario: any){
    if(usuario.nome !=='' && usuario.senha !== ''){
      this.loggedIn.next(true); //emite evento com o valor true
      this.router.navigate(['/']);
    }
  }

  logout(){
      this.loggedIn.next(false); //emite evento com o valor false
      this.router.navigate(['/login']);
  }
}
