import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from '../seguranca/auth.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  usuarioLogado$: Observable<boolean>;

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.usuarioLogado$ = this.authService.isUserLoggedIn;
  }

  logout(){
    this.authService.logout();
  }
}
